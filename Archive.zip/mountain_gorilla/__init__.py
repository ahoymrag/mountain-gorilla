"""
mountain_gorilla package initializer.
Contains the version string or any package-wide constants.
"""

__version__ = "0.1.0"
